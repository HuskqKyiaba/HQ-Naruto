import * as Minecraft from "@minecraft/server"

//Made by DerCoderJo
Minecraft.world.afterEvents.itemUse.subscribe(({itemStack, source}) => {
    source.addTag(`itemUse:${itemStack.typeId}`)
    if(itemStack.nameTag) try{source.addTag(`itemUseName:${itemStack.nameTag}`)}catch(err){console.error(err)}
    
    Minecraft.system.runTimeout(() => {
        source.runCommandAsync(`tag @s remove itemUse:${itemStack.typeId}`)
        source.runCommandAsync(`tag @s remove itemUseName:${itemStack.nameTag}`)
    })
})
//Made by DerCoderJo
Minecraft.world.afterEvents.itemUseOn.subscribe(({itemStack, source}) => {
    source.runCommandAsync(`tag @s add itemUseOn:${itemStack.typeId}`)
    if(itemStack.nameTag) source.addTag(`itemUseName:${itemStack.nameTag}`)

    Minecraft.system.runTimeout(() => {
        source.runCommandAsync(`tag @s remove itemUseOn:${itemStack.typeId}`)
        source.runCommandAsync(`tag @s remove itemUseName:${itemStack.nameTag}`)
    })
})
//Made by DerCoderJo